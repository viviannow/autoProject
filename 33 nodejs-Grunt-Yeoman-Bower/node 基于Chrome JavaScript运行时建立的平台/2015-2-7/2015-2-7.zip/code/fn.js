/**
 * Created by zmouse on 2015/2/7.
 */

/*
function fn(a, b) {
    return a + b;
}*/

/*global.fn = function(a, b) {
    return a + b;
}*/

/*module.exports = {
    a : 1,
    b : 2
}*/

exports = {
    a : 1,
    b : 2
}

/*exports.fn = function(a, b) {
    return a + b;
}*/

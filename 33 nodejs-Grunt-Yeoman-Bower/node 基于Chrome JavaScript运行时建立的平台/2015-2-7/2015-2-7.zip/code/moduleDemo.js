/**
 * Created by zmouse on 2015/2/7.
 *
 * 一个文件就是一个模块
 * 每个模块都有自己的独立的作用域
 *
 * require('fn')
 *
 */

var fn = require('fn');

console.log( fn );

//var value = fn.fn(1,2);
//console.log( value );
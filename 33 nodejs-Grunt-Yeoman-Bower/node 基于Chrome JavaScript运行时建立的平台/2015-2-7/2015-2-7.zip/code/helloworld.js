/**
 * Created by zmouse on 2015/2/7.
 */

console.log('Hello Nodejs');

var fs = require('fs');
fs.write();


var a = 1;

function fn(a) {

}

alert(a);

fn(1);